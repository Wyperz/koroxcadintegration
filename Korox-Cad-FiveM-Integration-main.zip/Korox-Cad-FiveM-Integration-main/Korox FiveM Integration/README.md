# KoroxCAD-cad-integration
 add "ensure mdt0.5" to your server.cfg file

https://koroxcad.com
